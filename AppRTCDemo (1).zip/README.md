# AppRTCDemo

Android Studio project for AppRTCDemo of WebRTC project.


This project now uses [the official prebuilt library](https://bintray.com/google/webrtc/google-webrtc) at jCenter